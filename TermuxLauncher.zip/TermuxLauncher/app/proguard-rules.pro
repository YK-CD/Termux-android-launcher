# Proguard rules for TermuxLauncher
-keep class com.termuxlauncher.** { *; }
