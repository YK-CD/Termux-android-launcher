package com.termuxlauncher.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.termuxlauncher.ui.theme.LocalTerminalTheme
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.hazeChild
import dev.chrisbanes.haze.materials.ExperimentalHazeMaterialsApi
import dev.chrisbanes.haze.materials.HazeMaterials

/**
 * Card com efeito glassmorphism.
 * Usa Haze para blur real quando disponível.
 */
@OptIn(ExperimentalHazeMaterialsApi::class)
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    hazeState: HazeState? = null,
    blurOpacity: Float = 0.08f,
    cornerRadius: Dp = 12.dp,
    contentPadding: Dp = 12.dp,
    content: @Composable BoxScope.() -> Unit
) {
    val theme = LocalTerminalTheme.current
    val shape = RoundedCornerShape(cornerRadius)

    val glassModifier = if (hazeState != null) {
        Modifier
            .clip(shape)
            .hazeChild(
                state = hazeState,
                shape = shape,
                style = HazeMaterials.thin(
                    containerColor = Color.White.copy(alpha = blurOpacity)
                )
            )
    } else {
        Modifier
            .clip(shape)
            .background(Color.White.copy(alpha = blurOpacity))
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .then(glassModifier)
            .border(
                width = 1.dp,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        theme.border.copy(alpha = 0.5f),
                        theme.border.copy(alpha = 0.15f)
                    )
                ),
                shape = shape
            )
            .padding(contentPadding),
        content = content
    )
}
