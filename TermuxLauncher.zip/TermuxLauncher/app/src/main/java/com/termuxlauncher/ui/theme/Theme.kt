package com.termuxlauncher.ui.theme

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

val LocalTerminalTheme = staticCompositionLocalOf { TerminalThemes.MatrixGreen }

@Composable
fun TermuxLauncherTheme(
    theme: TerminalTheme = TerminalThemes.MatrixGreen,
    content: @Composable () -> Unit
) {
    // Anima as cores ao trocar de tema
    val animatedAccent = animateColorAsState(theme.accent, tween(400), label = "accent")
    val animatedPrompt = animateColorAsState(theme.prompt, tween(400), label = "prompt")
    val animatedBorder = animateColorAsState(theme.border, tween(400), label = "border")
    val animatedGlow = animateColorAsState(theme.glow, tween(400), label = "glow")
    val animatedCursor = animateColorAsState(theme.cursor, tween(400), label = "cursor")

    val animatedTheme = theme.copy(
        accent = animatedAccent.value,
        prompt = animatedPrompt.value,
        border = animatedBorder.value,
        glow = animatedGlow.value,
        cursor = animatedCursor.value
    )

    CompositionLocalProvider(LocalTerminalTheme provides animatedTheme) {
        MaterialTheme(
            colorScheme = MaterialTheme.colorScheme.copy(
                primary = animatedTheme.accent,
                onPrimary = Color.Black,
                surface = Color.Transparent,
                onSurface = animatedTheme.textPrimary,
                background = Color.Transparent,
                onBackground = animatedTheme.textPrimary
            ),
            typography = TerminalTypography,
            content = content
        )
    }
}
