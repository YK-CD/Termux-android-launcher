package com.termuxlauncher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.termuxlauncher.ui.screens.AppDrawerScreen
import com.termuxlauncher.ui.screens.HomeScreen
import com.termuxlauncher.ui.screens.SettingsScreen
import com.termuxlauncher.ui.theme.TermuxLauncherTheme
import com.termuxlauncher.ui.viewmodel.LauncherViewModel
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.rememberHazeState

/**
 * Activity principal do launcher.
 * Configurada como HOME no Manifest.
 */
class MainActivity : ComponentActivity() {

    private val viewModel: LauncherViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        enableEdgeToEdge()
        WindowCompat.setDecorFitsSystemWindows(window, false)

        // Status bar transparente + ícones claros
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.TRANSPARENT
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }

        setContent {
            val theme by viewModel.currentTheme.collectAsState()
            val showDrawer by viewModel.showDrawer.collectAsState()
            val showSettings by viewModel.showSettings.collectAsState()
            val hazeState = rememberHazeState()

            TermuxLauncherTheme(theme = theme) {
                Box(Modifier.fillMaxSize()) {
                    HomeScreen(
                        viewModel = viewModel,
                        hazeState = hazeState,
                        onOpenDrawer = { viewModel.toggleDrawer(true) },
                        onOpenSettings = { viewModel.toggleSettings(true) }
                    )

                    AnimatedVisibility(
                        visible = showDrawer,
                        enter = fadeIn(tween(200)) + slideInVertically(
                            initialOffsetY = { it / 3 },
                            animationSpec = tween(250)
                        ),
                        exit = fadeOut(tween(150)) + slideOutVertically(
                            targetOffsetY = { it / 3 },
                            animationSpec = tween(200)
                        )
                    ) {
                        AppDrawerScreen(
                            viewModel = viewModel,
                            hazeState = hazeState,
                            onDismiss = { viewModel.toggleDrawer(false) }
                        )
                    }

                    AnimatedVisibility(
                        visible = showSettings,
                        enter = fadeIn(tween(200)) + slideInVertically(
                            initialOffsetY = { it / 4 },
                            animationSpec = tween(250)
                        ),
                        exit = fadeOut(tween(150))
                    ) {
                        SettingsScreen(
                            viewModel = viewModel,
                            hazeState = hazeState,
                            onDismiss = { viewModel.toggleSettings(false) }
                        )
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Recarrega apps caso algum tenha sido instalado/desinstalado
        viewModel.loadApps()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            viewModel.showSettings.value -> viewModel.toggleSettings(false)
            viewModel.showDrawer.value -> viewModel.toggleDrawer(false)
            else -> {
                // Em launcher, back não deve sair — apenas fecha overlays
            }
        }
    }
}
