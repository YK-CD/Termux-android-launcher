package com.termuxlauncher

import android.app.Application

class TermuxLauncherApp : Application()
