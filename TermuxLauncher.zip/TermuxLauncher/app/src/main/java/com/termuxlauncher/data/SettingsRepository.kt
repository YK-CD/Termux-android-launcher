package com.termuxlauncher.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "launcher_settings")

/**
 * Repositório de configurações persistentes via DataStore.
 */
class SettingsRepository(private val context: Context) {

    private object Keys {
        val THEME = stringPreferencesKey("theme")
        val FONT_SIZE = floatPreferencesKey("font_size")
        val BLUR_OPACITY = floatPreferencesKey("blur_opacity")
        val BLUR_INTENSITY = floatPreferencesKey("blur_intensity")
        val WALLPAPER_DIM = floatPreferencesKey("wallpaper_dim")
        val SHOW_CLOCK = booleanPreferencesKey("show_clock")
        val BLINKING_CURSOR = booleanPreferencesKey("blinking_cursor")
        val BOOT_ANIMATION = booleanPreferencesKey("boot_animation")
        val KEY_CLICK = booleanPreferencesKey("key_click")
        val DOCK_PACKAGES = stringSetPreferencesKey("dock_packages")
        val BLUR_WALLPAPER = booleanPreferencesKey("blur_wallpaper")
    }

    val settingsFlow: Flow<LauncherSettings> = context.dataStore.data.map { prefs ->
        LauncherSettings(
            themeName = prefs[Keys.THEME] ?: "Matrix Green",
            fontSize = prefs[Keys.FONT_SIZE] ?: 14f,
            blurOpacity = prefs[Keys.BLUR_OPACITY] ?: 0.08f,
            blurIntensity = prefs[Keys.BLUR_INTENSITY] ?: 12f,
            wallpaperDim = prefs[Keys.WALLPAPER_DIM] ?: 0.35f,
            showClock = prefs[Keys.SHOW_CLOCK] ?: true,
            blinkingCursor = prefs[Keys.BLINKING_CURSOR] ?: true,
            bootAnimation = prefs[Keys.BOOT_ANIMATION] ?: true,
            keyClick = prefs[Keys.KEY_CLICK] ?: false,
            dockPackages = prefs[Keys.DOCK_PACKAGES] ?: emptySet(),
            blurWallpaper = prefs[Keys.BLUR_WALLPAPER] ?: false
        )
    }

    suspend fun updateTheme(name: String) {
        context.dataStore.edit { it[Keys.THEME] = name }
    }

    suspend fun updateFontSize(size: Float) {
        context.dataStore.edit { it[Keys.FONT_SIZE] = size }
    }

    suspend fun updateBlurOpacity(opacity: Float) {
        context.dataStore.edit { it[Keys.BLUR_OPACITY] = opacity }
    }

    suspend fun updateBlurIntensity(intensity: Float) {
        context.dataStore.edit { it[Keys.BLUR_INTENSITY] = intensity }
    }

    suspend fun updateWallpaperDim(dim: Float) {
        context.dataStore.edit { it[Keys.WALLPAPER_DIM] = dim }
    }

    suspend fun updateShowClock(show: Boolean) {
        context.dataStore.edit { it[Keys.SHOW_CLOCK] = show }
    }

    suspend fun updateBlinkingCursor(blink: Boolean) {
        context.dataStore.edit { it[Keys.BLINKING_CURSOR] = blink }
    }

    suspend fun updateBootAnimation(enabled: Boolean) {
        context.dataStore.edit { it[Keys.BOOT_ANIMATION] = enabled }
    }

    suspend fun updateKeyClick(enabled: Boolean) {
        context.dataStore.edit { it[Keys.KEY_CLICK] = enabled }
    }

    suspend fun updateDockPackages(packages: Set<String>) {
        context.dataStore.edit { it[Keys.DOCK_PACKAGES] = packages }
    }

    suspend fun updateBlurWallpaper(enabled: Boolean) {
        context.dataStore.edit { it[Keys.BLUR_WALLPAPER] = enabled }
    }
}

data class LauncherSettings(
    val themeName: String = "Matrix Green",
    val fontSize: Float = 14f,
    val blurOpacity: Float = 0.08f,
    val blurIntensity: Float = 12f,
    val wallpaperDim: Float = 0.35f,
    val showClock: Boolean = true,
    val blinkingCursor: Boolean = true,
    val bootAnimation: Boolean = true,
    val keyClick: Boolean = false,
    val dockPackages: Set<String> = emptySet(),
    val blurWallpaper: Boolean = false
)
