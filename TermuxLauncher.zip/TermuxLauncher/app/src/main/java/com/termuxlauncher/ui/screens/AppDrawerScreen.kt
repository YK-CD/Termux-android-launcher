package com.termuxlauncher.ui.screens

import android.graphics.Bitmap
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import com.termuxlauncher.data.AppInfo
import com.termuxlauncher.ui.components.*
import com.termuxlauncher.ui.theme.LocalTerminalTheme
import com.termuxlauncher.ui.viewmodel.LauncherViewModel
import dev.chrisbanes.haze.HazeState

/**
 * App drawer estilo terminal com busca.
 */
@Composable
fun AppDrawerScreen(
    viewModel: LauncherViewModel,
    hazeState: HazeState,
    onDismiss: () -> Unit
) {
    val theme = LocalTerminalTheme.current
    val settings by viewModel.settings.collectAsState()
    val filteredApps by viewModel.filteredApps.collectAsState()
    val query by viewModel.searchQuery.collectAsState()
    val fontSize = settings.fontSize.sp
    val focusRequester = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        focusRequester.requestFocus()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.55f))
            .pointerInput(Unit) {
                detectTapGestures(onTap = { onDismiss() })
            }
    ) {
        GlassCard(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
                .statusBarsPadding()
                .navigationBarsPadding(),
            hazeState = hazeState,
            blurOpacity = settings.blurOpacity + 0.05f,
            cornerRadius = 16.dp,
            contentPadding = 12.dp
        ) {
            Column(Modifier.fillMaxSize()) {
                // Header
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    TerminalPrompt(fontSize = fontSize)
                    Spacer(Modifier.weight(1f))
                    TerminalText(
                        text = "[${filteredApps.size} apps]",
                        color = theme.textSecondary,
                        fontSize = (fontSize.value - 2).sp
                    )
                }

                Spacer(Modifier.height(8.dp))

                // Search field estilo terminal
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Color.White.copy(alpha = 0.05f),
                            RoundedCornerShape(8.dp)
                        )
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                ) {
                    TerminalText(
                        text = "$ search: ",
                        color = theme.prompt,
                        fontSize = fontSize
                    )
                    BasicTextField(
                        value = query,
                        onValueChange = { viewModel.onSearchChange(it) },
                        modifier = Modifier
                            .weight(1f)
                            .focusRequester(focusRequester),
                        textStyle = TextStyle(
                            color = theme.textPrimary,
                            fontSize = fontSize,
                            fontFamily = FontFamily.Monospace
                        ),
                        cursorBrush = SolidColor(theme.cursor),
                        singleLine = true,
                        decorationBox = { inner ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (query.isEmpty()) {
                                    TerminalText(
                                        text = "_",
                                        color = theme.textSecondary.copy(alpha = 0.4f),
                                        fontSize = fontSize
                                    )
                                }
                                inner()
                                if (settings.blinkingCursor) {
                                    BlinkingCursor(
                                        enabled = true,
                                        fontSize = fontSize
                                    )
                                }
                            }
                        }
                    )
                }

                Spacer(Modifier.height(10.dp))

                // Lista de apps
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(2.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(filteredApps, key = { it.packageName }) { app ->
                        AppCommandRow(
                            app = app,
                            fontSize = fontSize,
                            isPinned = viewModel.isPinned(app.packageName),
                            onLaunch = {
                                viewModel.launchApp(app)
                                onDismiss()
                            },
                            onInfo = { viewModel.openAppInfo(app) },
                            onUninstall = { viewModel.uninstallApp(app) },
                            onTogglePin = { viewModel.togglePin(app) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AppCommandRow(
    app: AppInfo,
    fontSize: androidx.compose.ui.unit.TextUnit,
    isPinned: Boolean,
    onLaunch: () -> Unit,
    onInfo: () -> Unit,
    onUninstall: () -> Unit,
    onTogglePin: () -> Unit
) {
    val theme = LocalTerminalTheme.current
    var showMenu by remember { mutableStateOf(false) }

    val bitmap = remember(app.icon) {
        app.icon?.toBitmap(40, 40, Bitmap.Config.ARGB_8888)?.asImageBitmap()
    }

    Box {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .pointerInput(Unit) {
                    detectTapGestures(
                        onTap = { onLaunch() },
                        onLongPress = { showMenu = true }
                    )
                }
                .padding(vertical = 6.dp, horizontal = 4.dp)
        ) {
            if (bitmap != null) {
                Image(
                    bitmap = bitmap,
                    contentDescription = null,
                    modifier = Modifier
                        .size(28.dp)
                        .clip(RoundedCornerShape(6.dp))
                )
                Spacer(Modifier.width(10.dp))
            }
            CommandPrefix(fontSize = fontSize)
            TerminalText(
                text = app.commandName,
                color = theme.textPrimary,
                fontSize = fontSize,
                maxLines = 1
            )
            if (isPinned) {
                Spacer(Modifier.width(6.dp))
                TerminalText(
                    text = "*",
                    color = theme.accent,
                    fontSize = fontSize
                )
            }
        }

        DropdownMenu(
            expanded = showMenu,
            onDismissRequest = { showMenu = false },
            modifier = Modifier.background(Color(0xFF1A1A1A))
        ) {
            DropdownMenuItem(
                text = { Text("info", fontFamily = FontFamily.Monospace, color = theme.textPrimary) },
                onClick = { showMenu = false; onInfo() }
            )
            DropdownMenuItem(
                text = {
                    Text(
                        if (isPinned) "unpin" else "pin",
                        fontFamily = FontFamily.Monospace,
                        color = theme.textPrimary
                    )
                },
                onClick = { showMenu = false; onTogglePin() }
            )
            DropdownMenuItem(
                text = { Text("uninstall", fontFamily = FontFamily.Monospace, color = Color(0xFFFF6666)) },
                onClick = { showMenu = false; onUninstall() }
            )
        }
    }
}
