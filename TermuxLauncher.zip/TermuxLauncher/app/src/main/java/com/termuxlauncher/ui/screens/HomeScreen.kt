package com.termuxlauncher.ui.screens

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import com.termuxlauncher.data.AppInfo
import com.termuxlauncher.ui.components.*
import com.termuxlauncher.ui.theme.LocalTerminalTheme
import com.termuxlauncher.ui.viewmodel.LauncherViewModel
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.haze

/**
 * Tela principal do launcher (HOME).
 */
@Composable
fun HomeScreen(
    viewModel: LauncherViewModel,
    hazeState: HazeState,
    onOpenDrawer: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val theme = LocalTerminalTheme.current
    val settings by viewModel.settings.collectAsState()
    val clock by viewModel.clock.collectAsState()
    val dockApps by viewModel.dockApps.collectAsState()
    val bootDone by viewModel.bootDone.collectAsState()
    val fontSize = settings.fontSize.sp

    Box(
        modifier = Modifier
            .fillMaxSize()
            .haze(hazeState)
            .pointerInput(Unit) {
                detectVerticalDragGestures { _, dragAmount ->
                    if (dragAmount < -40) onOpenDrawer() // swipe up
                }
            }
            .pointerInput(Unit) {
                detectTapGestures(
                    onDoubleTap = { /* double tap → busca (drawer com focus) */ onOpenDrawer() },
                    onLongPress = { onOpenSettings() }
                )
            }
    ) {
        // Overlay de escurecimento do wallpaper
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = settings.wallpaperDim))
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            // Top bar: clock + status
            if (settings.showClock) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TerminalText(
                        text = clock,
                        color = theme.accent,
                        fontSize = (fontSize.value - 1).sp
                    )
                    StatusBarText(fontSize = (fontSize.value - 2).sp)
                }
                Spacer(Modifier.height(8.dp))
            }

            // Boot animation / prompt
            if (!bootDone && settings.bootAnimation) {
                BootSequence(fontSize = fontSize)
            } else {
                TerminalPrompt(fontSize = fontSize)
                Spacer(Modifier.height(4.dp))
                TerminalText(
                    text = "Type 'apps' or swipe up to open drawer",
                    color = theme.textSecondary,
                    fontSize = (fontSize.value - 2).sp
                )
                Spacer(Modifier.height(8.dp))
                TerminalText(
                    text = "long-press → settings | double-tap → search",
                    color = theme.textSecondary.copy(alpha = 0.7f),
                    fontSize = (fontSize.value - 3).sp
                )
            }

            Spacer(Modifier.weight(1f))

            // Dock
            if (dockApps.isNotEmpty()) {
                GlassCard(
                    hazeState = hazeState,
                    blurOpacity = settings.blurOpacity,
                    cornerRadius = 16.dp,
                    contentPadding = 10.dp
                ) {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        items(dockApps, key = { it.packageName }) { app ->
                            DockItem(
                                app = app,
                                fontSize = fontSize,
                                onClick = { viewModel.launchApp(app) }
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            TerminalText(
                text = "─── swipe up for apps ───",
                color = theme.textSecondary.copy(alpha = 0.5f),
                fontSize = 10.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
        }
    }
}

@Composable
private fun BootSequence(fontSize: androidx.compose.ui.unit.TextUnit) {
    val lines = listOf(
        "OK" to "Loading kernel modules...",
        "OK" to "Mounting /system...",
        "OK" to "Starting package manager...",
        "OK" to "Initializing launcher...",
        "OK" to "Ready."
    )
    var visibleCount by remember { mutableIntStateOf(0) }

    LaunchedEffect(Unit) {
        lines.indices.forEach { i ->
            kotlinx.coroutines.delay(160)
            visibleCount = i + 1
        }
    }

    Column {
        lines.take(visibleCount).forEach { (status, msg) ->
            BootLogLine(status = status, message = msg, fontSize = (fontSize.value - 1).sp)
            Spacer(Modifier.height(2.dp))
        }
    }
}

@Composable
private fun DockItem(
    app: AppInfo,
    fontSize: androidx.compose.ui.unit.TextUnit,
    onClick: () -> Unit
) {
    val theme = LocalTerminalTheme.current
    val bitmap = remember(app.icon) {
        app.icon?.toBitmap(48, 48, Bitmap.Config.ARGB_8888)?.asImageBitmap()
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .pointerInput(Unit) {
                detectTapGestures(onTap = { onClick() })
            }
            .padding(4.dp)
    ) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap,
                contentDescription = app.label,
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(8.dp))
            )
        }
        Spacer(Modifier.height(2.dp))
        Text(
            text = app.commandName.take(8),
            color = theme.textSecondary,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            maxLines = 1
        )
    }
}
