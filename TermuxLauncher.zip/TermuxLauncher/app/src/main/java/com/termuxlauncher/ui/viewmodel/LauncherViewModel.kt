package com.termuxlauncher.ui.viewmodel

import android.app.Application
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.termuxlauncher.data.AppInfo
import com.termuxlauncher.data.LauncherSettings
import com.termuxlauncher.data.SettingsRepository
import com.termuxlauncher.ui.theme.TerminalThemes
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

/**
 * ViewModel principal do launcher.
 * Gerencia lista de apps, busca, dock e configurações.
 */
class LauncherViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = SettingsRepository(application)
    private val pm = application.packageManager

    private val _apps = MutableStateFlow<List<AppInfo>>(emptyList())
    val apps: StateFlow<List<AppInfo>> = _apps.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    val filteredApps: StateFlow<List<AppInfo>> = combine(_apps, _searchQuery) { apps, query ->
        if (query.isBlank()) apps
        else apps.filter {
            it.label.contains(query, ignoreCase = true) ||
            it.commandName.contains(query, ignoreCase = true) ||
            it.packageName.contains(query, ignoreCase = true)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val settings: StateFlow<LauncherSettings> = repo.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), LauncherSettings())

    val currentTheme = settings.map { TerminalThemes.fromName(it.themeName) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), TerminalThemes.MatrixGreen)

    private val _showDrawer = MutableStateFlow(false)
    val showDrawer: StateFlow<Boolean> = _showDrawer.asStateFlow()

    private val _showSettings = MutableStateFlow(false)
    val showSettings: StateFlow<Boolean> = _showSettings.asStateFlow()

    private val _bootDone = MutableStateFlow(false)
    val bootDone: StateFlow<Boolean> = _bootDone.asStateFlow()

    private val _clock = MutableStateFlow(formatClock())
    val clock: StateFlow<String> = _clock.asStateFlow()

    init {
        loadApps()
        startClock()
        // Simula boot animation
        viewModelScope.launch {
            kotlinx.coroutines.delay(900)
            _bootDone.value = true
        }
    }

    fun loadApps() {
        viewModelScope.launch {
            val list = withContext(Dispatchers.IO) {
                val intent = Intent(Intent.ACTION_MAIN).apply {
                    addCategory(Intent.CATEGORY_LAUNCHER)
                }
                pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
                    .mapNotNull { ri ->
                        try {
                            AppInfo(
                                label = ri.loadLabel(pm).toString(),
                                packageName = ri.activityInfo.packageName,
                                icon = ri.loadIcon(pm),
                                activityName = ri.activityInfo.name
                            )
                        } catch (e: Exception) {
                            null
                        }
                    }
                    .sortedBy { it.label.lowercase() }
            }
            _apps.value = list
        }
    }

    fun onSearchChange(query: String) {
        _searchQuery.value = query
    }

    fun clearSearch() {
        _searchQuery.value = ""
    }

    fun toggleDrawer(show: Boolean? = null) {
        _showDrawer.value = show ?: !_showDrawer.value
        if (_showDrawer.value) clearSearch()
    }

    fun toggleSettings(show: Boolean? = null) {
        _showSettings.value = show ?: !_showSettings.value
    }

    fun launchApp(app: AppInfo) {
        try {
            val intent = pm.getLaunchIntentForPackage(app.packageName)
            intent?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            getApplication<Application>().startActivity(intent)
        } catch (e: Exception) {
            // App não encontrado / sem activity
        }
    }

    fun openAppInfo(app: AppInfo) {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.parse("package:${app.packageName}")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        getApplication<Application>().startActivity(intent)
    }

    fun uninstallApp(app: AppInfo) {
        val intent = Intent(Intent.ACTION_DELETE).apply {
            data = Uri.parse("package:${app.packageName}")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        getApplication<Application>().startActivity(intent)
    }

    fun togglePin(app: AppInfo) {
        viewModelScope.launch {
            val current = settings.value.dockPackages.toMutableSet()
            if (current.contains(app.packageName)) {
                current.remove(app.packageName)
            } else if (current.size < 5) {
                current.add(app.packageName)
            }
            repo.updateDockPackages(current)
        }
    }

    fun isPinned(packageName: String): Boolean =
        settings.value.dockPackages.contains(packageName)

    val dockApps: StateFlow<List<AppInfo>> = combine(_apps, settings) { apps, s ->
        s.dockPackages.mapNotNull { pkg -> apps.find { it.packageName == pkg } }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Configurações ---
    fun setTheme(name: String) = viewModelScope.launch { repo.updateTheme(name) }
    fun setFontSize(size: Float) = viewModelScope.launch { repo.updateFontSize(size) }
    fun setBlurOpacity(v: Float) = viewModelScope.launch { repo.updateBlurOpacity(v) }
    fun setBlurIntensity(v: Float) = viewModelScope.launch { repo.updateBlurIntensity(v) }
    fun setWallpaperDim(v: Float) = viewModelScope.launch { repo.updateWallpaperDim(v) }
    fun setShowClock(v: Boolean) = viewModelScope.launch { repo.updateShowClock(v) }
    fun setBlinkingCursor(v: Boolean) = viewModelScope.launch { repo.updateBlinkingCursor(v) }
    fun setBootAnimation(v: Boolean) = viewModelScope.launch { repo.updateBootAnimation(v) }
    fun setKeyClick(v: Boolean) = viewModelScope.launch { repo.updateKeyClick(v) }
    fun setBlurWallpaper(v: Boolean) = viewModelScope.launch { repo.updateBlurWallpaper(v) }

    private fun startClock() {
        viewModelScope.launch {
            while (true) {
                _clock.value = formatClock()
                kotlinx.coroutines.delay(1000)
            }
        }
    }

    private fun formatClock(): String {
        val sdf = SimpleDateFormat("[HH:mm:ss] dd/MM/yyyy", Locale.getDefault())
        return sdf.format(Date())
    }
}
