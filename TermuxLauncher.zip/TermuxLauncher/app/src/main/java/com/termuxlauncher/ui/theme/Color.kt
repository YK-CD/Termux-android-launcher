package com.termuxlauncher.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * Temas de cores estilo terminal.
 * Cada tema define: accent, prompt, border, glow e cursor.
 */
data class TerminalTheme(
    val name: String,
    val accent: Color,
    val prompt: Color,
    val border: Color,
    val glow: Color,
    val cursor: Color,
    val textPrimary: Color = Color(0xFFE0E0E0),
    val textSecondary: Color = Color(0xFFAAAAAA),
    val backgroundOverlay: Color = Color.Black.copy(alpha = 0.35f)
)

object TerminalThemes {
    val MatrixGreen = TerminalTheme(
        name = "Matrix Green",
        accent = Color(0xFF00FF41),
        prompt = Color(0xFF00FF41),
        border = Color(0xFF00FF41).copy(alpha = 0.25f),
        glow = Color(0xFF00FF41).copy(alpha = 0.4f),
        cursor = Color(0xFF00FF41)
    )

    val Cyberpunk = TerminalTheme(
        name = "Cyberpunk Magenta",
        accent = Color(0xFFFF00FF),
        prompt = Color(0xFF00FFFF),
        border = Color(0xFFFF00FF).copy(alpha = 0.3f),
        glow = Color(0xFFFF00FF).copy(alpha = 0.45f),
        cursor = Color(0xFF00FFFF)
    )

    val Amber = TerminalTheme(
        name = "Amber Terminal",
        accent = Color(0xFFFFB000),
        prompt = Color(0xFFFFB000),
        border = Color(0xFFFFB000).copy(alpha = 0.28f),
        glow = Color(0xFFFFB000).copy(alpha = 0.4f),
        cursor = Color(0xFFFFB000)
    )

    val Dracula = TerminalTheme(
        name = "Dracula",
        accent = Color(0xFFBD93F9),
        prompt = Color(0xFFFF79C6),
        border = Color(0xFFBD93F9).copy(alpha = 0.3f),
        glow = Color(0xFFBD93F9).copy(alpha = 0.4f),
        cursor = Color(0xFFFF79C6)
    )

    val Nord = TerminalTheme(
        name = "Nord",
        accent = Color(0xFF88C0D0),
        prompt = Color(0xFF81A1C1),
        border = Color(0xFF88C0D0).copy(alpha = 0.28f),
        glow = Color(0xFF88C0D0).copy(alpha = 0.4f),
        cursor = Color(0xFF81A1C1)
    )

    val Solarized = TerminalTheme(
        name = "Solarized Dark",
        accent = Color(0xFF268BD2),
        prompt = Color(0xFFB58900),
        border = Color(0xFF268BD2).copy(alpha = 0.28f),
        glow = Color(0xFF268BD2).copy(alpha = 0.4f),
        cursor = Color(0xFFB58900)
    )

    val Gruvbox = TerminalTheme(
        name = "Gruvbox",
        accent = Color(0xFFFABD2F),
        prompt = Color(0xFFFB4934),
        border = Color(0xFFFABD2F).copy(alpha = 0.3f),
        glow = Color(0xFFFABD2F).copy(alpha = 0.4f),
        cursor = Color(0xFFFB4934)
    )

    val TokyoNight = TerminalTheme(
        name = "Tokyo Night",
        accent = Color(0xFF7AA2F7),
        prompt = Color(0xFFBB9AF7),
        border = Color(0xFF7AA2F7).copy(alpha = 0.28f),
        glow = Color(0xFF7AA2F7).copy(alpha = 0.4f),
        cursor = Color(0xFFBB9AF7)
    )

    val all = listOf(
        MatrixGreen, Cyberpunk, Amber, Dracula,
        Nord, Solarized, Gruvbox, TokyoNight
    )

    fun fromName(name: String): TerminalTheme =
        all.find { it.name == name } ?: MatrixGreen
}
