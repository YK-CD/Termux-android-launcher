package com.termuxlauncher.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.termuxlauncher.ui.theme.LocalTerminalTheme

/**
 * Texto estilo terminal com fonte monospace.
 */
@Composable
fun TerminalText(
    text: String,
    modifier: Modifier = Modifier,
    color: Color? = null,
    fontSize: TextUnit = 14.sp,
    fontWeight: FontWeight = FontWeight.Normal,
    maxLines: Int = Int.MAX_VALUE
) {
    val theme = LocalTerminalTheme.current
    Text(
        text = text,
        modifier = modifier,
        color = color ?: theme.textPrimary,
        fontSize = fontSize,
        fontFamily = FontFamily.Monospace,
        fontWeight = fontWeight,
        maxLines = maxLines
    )
}

/**
 * Prompt de terminal: [user@device ~]$
 */
@Composable
fun TerminalPrompt(
    modifier: Modifier = Modifier,
    user: String = "user",
    host: String = "android",
    path: String = "~",
    fontSize: TextUnit = 13.sp
) {
    val theme = LocalTerminalTheme.current
    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically) {
        TerminalText(
            text = "[",
            color = theme.textSecondary,
            fontSize = fontSize
        )
        TerminalText(
            text = user,
            color = theme.prompt,
            fontSize = fontSize,
            fontWeight = FontWeight.Bold
        )
        TerminalText(
            text = "@$host ",
            color = theme.accent,
            fontSize = fontSize
        )
        TerminalText(
            text = path,
            color = theme.prompt,
            fontSize = fontSize
        )
        TerminalText(
            text = "]$ ",
            color = theme.textSecondary,
            fontSize = fontSize
        )
    }
}

/**
 * Cursor piscante estilo terminal.
 */
@Composable
fun BlinkingCursor(
    enabled: Boolean = true,
    color: Color? = null,
    fontSize: TextUnit = 14.sp
) {
    val theme = LocalTerminalTheme.current
    val infiniteTransition = rememberInfiniteTransition(label = "cursor")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(500, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "cursorAlpha"
    )

    Text(
        text = "█",
        color = color ?: theme.cursor,
        fontSize = fontSize,
        fontFamily = FontFamily.Monospace,
        modifier = Modifier.alpha(if (enabled) alpha else 1f)
    )
}

/**
 * Prefixo de comando: >
 */
@Composable
fun CommandPrefix(
    modifier: Modifier = Modifier,
    fontSize: TextUnit = 13.sp
) {
    val theme = LocalTerminalTheme.current
    TerminalText(
        text = "> ",
        color = theme.prompt,
        fontSize = fontSize,
        fontWeight = FontWeight.Bold,
        modifier = modifier
    )
}

/**
 * Linha de log estilo boot: [ OK ] Loading modules...
 */
@Composable
fun BootLogLine(
    status: String = "OK",
    message: String,
    modifier: Modifier = Modifier,
    fontSize: TextUnit = 12.sp
) {
    val theme = LocalTerminalTheme.current
    val statusColor = when (status.uppercase()) {
        "OK" -> Color(0xFF00FF41)
        "WARN" -> Color(0xFFFFB000)
        "FAIL" -> Color(0xFFFF4444)
        else -> theme.accent
    }
    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically) {
        TerminalText(text = "[ ", color = theme.textSecondary, fontSize = fontSize)
        TerminalText(text = status, color = statusColor, fontSize = fontSize, fontWeight = FontWeight.Bold)
        TerminalText(text = " ] ", color = theme.textSecondary, fontSize = fontSize)
        TerminalText(text = message, color = theme.textPrimary, fontSize = fontSize)
    }
}

/**
 * Status bar minimalista: BAT: 87% | WIFI: ON
 */
@Composable
fun StatusBarText(
    battery: Int = 87,
    wifiOn: Boolean = true,
    modifier: Modifier = Modifier,
    fontSize: TextUnit = 11.sp
) {
    val theme = LocalTerminalTheme.current
    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically) {
        TerminalText(
            text = "BAT: $battery%",
            color = if (battery > 20) theme.accent else Color(0xFFFF4444),
            fontSize = fontSize
        )
        Spacer(Modifier.width(8.dp))
        TerminalText(text = "|", color = theme.textSecondary, fontSize = fontSize)
        Spacer(Modifier.width(8.dp))
        TerminalText(
            text = "WIFI: ${if (wifiOn) "ON" else "OFF"}",
            color = if (wifiOn) theme.accent else theme.textSecondary,
            fontSize = fontSize
        )
    }
}
