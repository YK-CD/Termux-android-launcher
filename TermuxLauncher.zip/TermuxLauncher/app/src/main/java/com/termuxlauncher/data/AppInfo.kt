package com.termuxlauncher.data

import android.graphics.drawable.Drawable

/**
 * Modelo de um aplicativo instalado.
 */
data class AppInfo(
    val label: String,
    val packageName: String,
    val icon: Drawable?,
    val activityName: String? = null
) {
    /** Representação estilo comando de terminal */
    val commandName: String
        get() = label.lowercase()
            .replace(" ", "-")
            .replace(Regex("[^a-z0-9\\-.]"), "")
}
