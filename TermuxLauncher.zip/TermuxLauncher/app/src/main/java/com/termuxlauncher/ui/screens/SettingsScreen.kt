package com.termuxlauncher.ui.screens

import android.app.WallpaperManager
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.termuxlauncher.ui.components.GlassCard
import com.termuxlauncher.ui.components.TerminalText
import com.termuxlauncher.ui.theme.LocalTerminalTheme
import com.termuxlauncher.ui.theme.TerminalTheme
import com.termuxlauncher.ui.theme.TerminalThemes
import com.termuxlauncher.ui.viewmodel.LauncherViewModel
import dev.chrisbanes.haze.HazeState

/**
 * Tela de configurações com cards glass.
 */
@Composable
fun SettingsScreen(
    viewModel: LauncherViewModel,
    hazeState: HazeState,
    onDismiss: () -> Unit
) {
    val theme = LocalTerminalTheme.current
    val settings by viewModel.settings.collectAsState()
    val context = LocalContext.current
    val fontSize = settings.fontSize.sp

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.6f))
            .clickable { onDismiss() }
    ) {
        GlassCard(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
                .statusBarsPadding()
                .navigationBarsPadding()
                .clickable(enabled = false) {},
            hazeState = hazeState,
            blurOpacity = settings.blurOpacity + 0.06f,
            cornerRadius = 16.dp,
            contentPadding = 0.dp
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        TerminalText(
                            text = "$ settings",
                            color = theme.prompt,
                            fontSize = (fontSize.value + 2).sp
                        )
                        Spacer(Modifier.weight(1f))
                        TerminalText(
                            text = "[x] close",
                            color = theme.textSecondary,
                            fontSize = (fontSize.value - 2).sp,
                            modifier = Modifier.clickable { onDismiss() }
                        )
                    }
                }

                // === Aparência ===
                item {
                    SectionTitle(":: aparência", fontSize)
                }
                item {
                    TerminalText("tema de cores", color = theme.textSecondary, fontSize = (fontSize.value - 1).sp)
                    Spacer(Modifier.height(8.dp))
                    ThemeGrid(
                        current = settings.themeName,
                        onSelect = { viewModel.setTheme(it) }
                    )
                }
                item {
                    SliderRow(
                        label = "tamanho da fonte",
                        value = settings.fontSize,
                        range = 10f..24f,
                        valueLabel = "${settings.fontSize.toInt()}sp",
                        onChange = { viewModel.setFontSize(it) },
                        fontSize = fontSize
                    )
                }
                item {
                    SliderRow(
                        label = "opacidade do glass",
                        value = settings.blurOpacity * 100f,
                        range = 0f..30f,
                        valueLabel = "${(settings.blurOpacity * 100).toInt()}%",
                        onChange = { viewModel.setBlurOpacity(it / 100f) },
                        fontSize = fontSize
                    )
                }
                item {
                    SliderRow(
                        label = "intensidade do blur",
                        value = settings.blurIntensity,
                        range = 0f..25f,
                        valueLabel = "${settings.blurIntensity.toInt()}dp",
                        onChange = { viewModel.setBlurIntensity(it) },
                        fontSize = fontSize
                    )
                }

                // === Wallpaper ===
                item {
                    SectionTitle(":: wallpaper", fontSize)
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ActionButton(
                            text = "trocar wallpaper",
                            onClick = {
                                try {
                                    val intent = Intent(Intent.ACTION_SET_WALLPAPER)
                                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    context.startActivity(intent)
                                } catch (_: Exception) {
                                    try {
                                        val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
                                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                        context.startActivity(intent)
                                    } catch (_: Exception) {}
                                }
                            },
                            fontSize = fontSize
                        )
                    }
                }
                item {
                    SliderRow(
                        label = "escurecimento",
                        value = settings.wallpaperDim * 100f,
                        range = 0f..80f,
                        valueLabel = "${(settings.wallpaperDim * 100).toInt()}%",
                        onChange = { viewModel.setWallpaperDim(it / 100f) },
                        fontSize = fontSize
                    )
                }
                item {
                    ToggleRow(
                        label = "blur no wallpaper",
                        checked = settings.blurWallpaper,
                        onChange = { viewModel.setBlurWallpaper(it) },
                        fontSize = fontSize
                    )
                }

                // === Comportamento ===
                item {
                    SectionTitle(":: comportamento", fontSize)
                }
                item {
                    ToggleRow("mostrar relógio", settings.showClock, { viewModel.setShowClock(it) }, fontSize)
                }
                item {
                    ToggleRow("cursor piscante", settings.blinkingCursor, { viewModel.setBlinkingCursor(it) }, fontSize)
                }
                item {
                    ToggleRow("animação de boot", settings.bootAnimation, { viewModel.setBootAnimation(it) }, fontSize)
                }
                item {
                    ToggleRow("som de tecla", settings.keyClick, { viewModel.setKeyClick(it) }, fontSize)
                }

                // === Sobre ===
                item {
                    SectionTitle(":: sobre", fontSize)
                }
                item {
                    TerminalText(
                        text = "TermuxLauncher v1.0.0\nKotlin + Jetpack Compose\nGlassmorphism + Terminal UI\n\nFeito para quem sente falta do $",
                        color = theme.textSecondary,
                        fontSize = (fontSize.value - 1).sp
                    )
                }

                item { Spacer(Modifier.height(24.dp)) }
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String, fontSize: androidx.compose.ui.unit.TextUnit) {
    val theme = LocalTerminalTheme.current
    TerminalText(
        text = text,
        color = theme.accent,
        fontSize = fontSize
    )
}

@Composable
private fun ThemeGrid(
    current: String,
    onSelect: (String) -> Unit
) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.height(280.dp)
    ) {
        items(TerminalThemes.all) { t ->
            ThemePreviewCard(
                theme = t,
                selected = t.name == current,
                onClick = { onSelect(t.name) }
            )
        }
    }
}

@Composable
private fun ThemePreviewCard(
    theme: TerminalTheme,
    selected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .height(56.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Color.White.copy(alpha = 0.06f))
            .border(
                width = if (selected) 2.dp else 1.dp,
                color = if (selected) theme.accent else theme.border,
                shape = RoundedCornerShape(10.dp)
            )
            .clickable(onClick = onClick)
            .padding(10.dp)
    ) {
        Column {
            TerminalText(
                text = theme.name,
                color = theme.accent,
                fontSize = 11.sp
            )
            TerminalText(
                text = "> prompt",
                color = theme.prompt,
                fontSize = 10.sp
            )
        }
    }
}

@Composable
private fun SliderRow(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    valueLabel: String,
    onChange: (Float) -> Unit,
    fontSize: androidx.compose.ui.unit.TextUnit
) {
    val theme = LocalTerminalTheme.current
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            TerminalText(text = label, color = theme.textSecondary, fontSize = (fontSize.value - 1).sp)
            TerminalText(text = valueLabel, color = theme.accent, fontSize = (fontSize.value - 1).sp)
        }
        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = range,
            colors = androidx.compose.material3.SliderDefaults.colors(
                thumbColor = theme.accent,
                activeTrackColor = theme.accent,
                inactiveTrackColor = theme.border
            )
        )
    }
}

@Composable
private fun ToggleRow(
    label: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit,
    fontSize: androidx.compose.ui.unit.TextUnit
) {
    val theme = LocalTerminalTheme.current
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        TerminalText(text = label, color = theme.textPrimary, fontSize = (fontSize.value - 1).sp)
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = theme.accent,
                checkedTrackColor = theme.accent.copy(alpha = 0.4f),
                uncheckedThumbColor = theme.textSecondary,
                uncheckedTrackColor = theme.border
            )
        )
    }
}

@Composable
private fun ActionButton(
    text: String,
    onClick: () -> Unit,
    fontSize: androidx.compose.ui.unit.TextUnit
) {
    val theme = LocalTerminalTheme.current
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(theme.accent.copy(alpha = 0.15f))
            .border(1.dp, theme.border, RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        TerminalText(text = "> $text", color = theme.accent, fontSize = (fontSize.value - 1).sp)
    }
}
