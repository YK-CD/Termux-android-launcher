# TermuxLauncher

Launcher Android com estética de terminal Unix (estilo Termux) + glassmorphism.

## Características

- **Visual terminal**: fontes monospace, prompts `$`, `>`, logs estilo CLI
- **Glassmorphism real**: blur via biblioteca Haze + cards semi-transparentes
- **Fundo transparente**: wallpaper do sistema visível atrás do launcher
- **8 temas de cores**: Matrix Green, Cyberpunk, Amber, Dracula, Nord, Solarized, Gruvbox, Tokyo Night
- **App drawer** com busca em tempo real estilo `$ search:`
- **Dock** de até 5 apps favoritos
- **Gestos**: swipe up → drawer, long-press → settings, double-tap → busca
- **Configurações persistentes** via DataStore
- **Animação de boot** com linhas de log

## Requisitos

- Android Studio Hedgehog (2023.1.1) ou superior
- JDK 17
- Min SDK 26 / Target SDK 34

## Build

```bash
# Clone / abra o projeto no Android Studio
# Ou via linha de comando:

./gradlew assembleDebug

# APK gerado em:
# app/build/outputs/apk/debug/app-debug.apk
```

## Configurar como launcher padrão

1. Instale o APK
2. Pressione o botão Home
3. Selecione **TermuxLauncher** e marque "Sempre"

## Estrutura

```
app/src/main/java/com/termuxlauncher/
├── MainActivity.kt
├── TermuxLauncherApp.kt
├── data/
│   ├── AppInfo.kt
│   └── SettingsRepository.kt
├── ui/
│   ├── components/
│   │   ├── GlassCard.kt
│   │   └── TerminalComponents.kt
│   ├── screens/
│   │   ├── HomeScreen.kt
│   │   ├── AppDrawerScreen.kt
│   │   └── SettingsScreen.kt
│   ├── theme/
│   │   ├── Color.kt          # 8 temas
│   │   ├── Theme.kt
│   │   └── Type.kt
│   └── viewmodel/
│       └── LauncherViewModel.kt
```

## Permissões

| Permissão | Uso |
|-----------|-----|
| `QUERY_ALL_PACKAGES` | Listar apps instalados |
| `SET_WALLPAPER` | Trocar wallpaper |
| `EXPAND_STATUS_BAR` | (opcional) expandir notificações |

## Notas técnicas

- **Blur**: usa [Haze](https://github.com/chrisbanes/haze) (RenderEffect no API 31+, fallback). Sem Haze o glass fica só com alpha.
- **Wallpaper**: `android:windowShowWallpaper=true` + `windowIsTranslucent=true`.
- **HOME intent**: `category.HOME` + `DEFAULT` no Manifest.
- **Arquitetura**: MVVM simples com StateFlow + DataStore.

## Temas disponíveis

1. Matrix Green — `#00FF41`
2. Cyberpunk Magenta — `#FF00FF` + `#00FFFF`
3. Amber Terminal — `#FFB000`
4. Dracula — `#BD93F9` + `#FF79C6`
5. Nord — `#88C0D0`
6. Solarized Dark — `#268BD2`
7. Gruvbox — `#FABD2F`
8. Tokyo Night — `#7AA2F7`

## Licença

MIT — use como quiser.
